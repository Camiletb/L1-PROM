Lab PROM
